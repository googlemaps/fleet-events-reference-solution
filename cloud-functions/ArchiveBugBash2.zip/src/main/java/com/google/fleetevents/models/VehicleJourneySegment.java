/*
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.fleetevents.models;

import com.google.cloud.firestore.GeoPoint;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Firestore serializable representation of the vehicle journey segment object.
 */
public class VehicleJourneySegment implements Serializable {

  private GeoPoint plannedLocation;
  private Long duration;
  private int distance;
  private List<String> taskIds;
  private VehicleStop vehicleStop;

  private VehicleJourneySegment() {
  }

  public static Builder builder() {
    return new VehicleJourneySegment.Builder()
        .setDistance(0)
        .setDuration(Long.valueOf(0))
        .setPlannedLocation(new GeoPoint(0, 0))
        .setTaskIds(new ArrayList<>());
  }

  public Builder toBuilder() {
    return new Builder(this);
  }

  public GeoPoint getPlannedLocation() {
    return plannedLocation;
  }

  // duration in milliseconds.
  public Long getDuration() {
    return duration;
  }

  public int getDistance() {
    return distance;
  }

  public List<String> getTaskIds() {
    return taskIds;
  }

  public VehicleStop getVehicleStop() {
    return vehicleStop;
  }

  @Override
  public String toString() {
    return "VehicleJourneySegment{"
        + "plannedLocation="
        + plannedLocation
        + ", duration="
        + duration
        + ", distance="
        + distance
        + ", taskIds="
        + taskIds
        + ", vehicleStop="
        + vehicleStop
        + '}';
  }

  @Override
  public boolean equals(Object object) {
    if (object instanceof VehicleJourneySegment) {
      VehicleJourneySegment that = (VehicleJourneySegment) object;
      return Objects.equals(that.plannedLocation, this.plannedLocation)
          && Objects.equals(that.duration, this.duration)
          && Objects.equals(that.distance, this.distance)
          && Objects.equals(that.taskIds, this.taskIds)
          && Objects.equals(that.vehicleStop, this.vehicleStop);
    }
    return false;
  }

  public static class Builder {

    VehicleJourneySegment vehicleJourneySegment;

    Builder() {
      vehicleJourneySegment = new VehicleJourneySegment();
    }

    Builder(VehicleJourneySegment vehicleJourneySegment) {
      this.vehicleJourneySegment = vehicleJourneySegment;
    }

    public Builder setPlannedLocation(GeoPoint plannedLocation) {
      vehicleJourneySegment.plannedLocation = plannedLocation;
      return this;
    }

    public Builder setDuration(Long duration) {
      vehicleJourneySegment.duration = duration;
      return this;
    }

    public Builder setDistance(int distance) {
      vehicleJourneySegment.distance = distance;
      return this;
    }

    public Builder setTaskIds(List<String> taskIds) {
      vehicleJourneySegment.taskIds = taskIds;
      return this;
    }

    public Builder setVehicleStop(VehicleStop stop) {
      vehicleJourneySegment.vehicleStop = stop;
      return this;
    }

    public VehicleJourneySegment build() {
      return vehicleJourneySegment;
    }
  }
}
